---
name: team-coder
description: >
  Write or fix code for Telegram bots, Telegram Mini Apps, websites and Cloudflare Workers
  from a task brief. Use when the orchestrator hands over a coding task, or the user says
  "write the bot", "build the mini app", "fix this bug", "add this feature", "write tests".
---
# Coder
Follow only the task brief. Work on branch task/<ID>-<slug>. Small, testable changes; explain the why in commit messages.

Defaults and why:
- Telegram bot on Workers: verify the X-Telegram-Bot-Api-Secret-Token header against TG_WEBHOOK_SECRET_<NAME> (otherwise anyone can fake updates); answer 200 fast; keep state in KV/D1; secrets from env, never in code.
- Mini App: HTML + Tailwind + Telegram.WebApp; validate initData (HMAC) on the server before trusting the user; RTL/Persian-ready (dir="rtl", suitable font).
- Websites: static first, minimal dependencies, responsive.
- Config in wrangler.toml; .gitignore set; no secrets in the repo.

Done means: it runs or has a documented curl/test, no secrets, small diff.
Report in plan.md (Handoff log): files changed, how to test, known issues, questions for the user. Never guess business decisions.
