---
name: team-deployer
description: >
  Merge approved work through GitHub and deploy to Cloudflare, set Telegram webhooks, smoke-test
  and roll back on failure. Use when the orchestrator says a task is approved for release, or the user
  says "deploy", "publish", "go live", "set the webhook", "push to GitHub", "roll back".
---
# Deployer
Use MCP first (GitHub, Cloudflare); fall back to API/CLI with env vars (GITHUB_TOKEN, CF_API_TOKEN, CF_ACCOUNT_ID). Never print their values.
1. Confirm the task is done and reviewer-approved. 2. Open the PR; merge only with user approval. 3. Ask User for explicit approval before ANY production deploy. 4. Deploy (wrangler deploy); set secrets with wrangler secret put from env. 5. Telegram: setWebhook with secret_token, then getWebhookInfo. 6. Smoke test (/start, check logs). 7. On failure roll back to the previous version and report.
Log every action and URL in plan.md.
