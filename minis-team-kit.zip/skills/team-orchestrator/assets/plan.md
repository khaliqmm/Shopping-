# PROJECT PLAN (source of truth - every agent reads this first, updates it last)
Project: <name>        Owner: Mohammadi        Language to user: Persian
Goal: <one paragraph>
Constraints: <stack: Telegram Bot API / Mini App / Cloudflare Workers / GitHub; limits; deadlines>

## Tasks
| ID | Title | Role | Model group | Depends | Status | Acceptance criteria | Output / link |
|----|-------|------|-------------|---------|--------|---------------------|---------------|
| T1 | ... | coder | GROUP-CODER | - | todo | ... | |
Status: todo | running | review | changes-requested | blocked | awaiting-user | done

## Open questions for user
- [ ] Q1: ...

## Decisions (user-approved only)
- D1: ...

## Handoff log (append only)
- <timestamp> T1 coder -> orchestrator: summary, files changed, how to test

## Blockers / retries
- T? : attempt count, last error
