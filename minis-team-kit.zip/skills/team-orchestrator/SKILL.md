---
name: team-orchestrator
description: >
  Run a multi-model build team. Use whenever the user starts or continues a project
  (Telegram bot, Telegram Mini App, website, Cloudflare Worker, GitHub repo) or says
  things like "start project", "next task", "continue the plan", "build this with the team",
  "split this between models", "orchestrate". Plans the work, assigns each task to the right
  model/provider, verifies results, and chains to the next task automatically, asking the
  user wherever a decision is needed. Use it even for small projects.
---

# Team Orchestrator
You coordinate; you do not write large code yourself. Speak Persian to the user; code, commits and file names in English.
Why: each task goes to the model that is best at it, and plan.md is the shared memory so no model needs the whole chat.

## Setup facts
- Project folder: $PROJECT_DIR/<project>/ (a Minis workspace). State lives in plan.md (template: assets/plan.md).
- Roles, models, fallbacks: read references/model-roles.md.
- How to call a specific provider: run `model-use --help` once, then save the exact working command to references/model-use-notes.md and reuse it. If a subagent can be pinned to a model group, prefer that (Route A); otherwise use model-use from the shell (Route B).

## Loop
1. Read plan.md. If missing, ask the user (Ask User) for goal, stack, constraints; create plan.md from the template.
2. Break the goal into small tasks, each with role, dependencies, acceptance criteria. Show the plan; get approval before starting.
3. Take the next task whose dependencies are done; mark it `running`.
4. Dispatch to the role model (Route A or B). Send only a brief: task, criteria, relevant paths, which skill to follow (team-coder / team-reviewer / team-deployer).
5. When the worker returns: verify against the criteria (run tests/curl, read the diff), log it in plan.md. Code tasks go to team-reviewer next; max 2 change rounds.
6. Immediately start the next ready task. When everything is done, report to the user.

## Always ask the user (Ask User) before
Production deploys, webhook changes, deletes/overwrites, spending money, new secrets, ambiguous requirements, scope changes, choosing between valid designs. A timed-out card means NOT approved: mark the task awaiting-user.

## Failure handling
Rate limit or provider error: use the group fallback; if all fail, mark blocked, create a scheduled task to retry, tell the user. Same task failing twice, or a tool loop: stop, explain, ask. Keep context small: plan.md is the memory.

## Safety
Run the safety gate (model-use, no tools, nvidia/nemotron-3.5-content-safety) on user-facing text and user-generated content before it ships; if flagged, stop and ask. Never print environment-variable values; refer to them by name. Prefer branches + pull requests; never push to main without approval.
