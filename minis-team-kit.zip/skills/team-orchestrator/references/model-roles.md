# Model -> Role map (one provider entry + one dedicated account per row)

| Provider in Minis | Model ID | Role | Why |
|---|---|---|---|
| GEMINI-ORCH (AI Studio key 1) | Gemini 3.5 Flash | ORCHESTRATOR | fast, reliable tool calling, plans + routes + verifies |
| OR-CODER-A (OpenRouter acct 1) | nvidia/nemotron-3-ultra-550b-a55b:free | CODER-A (architecture, hard code) | frontier reasoning/planning MoE |
| OR-CODER-B (OpenRouter acct 2) | cohere/north-mini-code:free | CODER-B (implement, tests, bugfix, terminal tasks) | agentic coding model, 256K ctx, 64K output, tools |
| OR-REVIEW (OpenRouter acct 3) | nvidia/nemotron-3.5-super-vl:free | REVIEWER + visual QA | 1M context (whole repo), reads screenshots/GUIs/docs, reasoning on |
| GEMINI-DEPLOY (AI Studio key 2) | Gemini 3.5 Flash | DEPLOYER | careful tool use for GitHub/Cloudflare MCP + API |
| OR-FAST (OpenRouter acct 4) | nvidia/nemotron-3.5-lightning:free | FAST helper | cheap high-throughput: summaries, plan.md updates, log triage, README, changelog |
| OR-OMNI (OpenRouter acct 5) | nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free | VISION / multimodal helper | set as Minis "Vision Input" describer for text-only models |
| OR-SAFETY (OpenRouter acct 6) | nvidia/nemotron-3.5-content-safety:free | SAFETY GATE (not a chat/worker model) | guardrail classifier: safe/unsafe + category; no tool calling |

## Fallback chains (Model Groups, strategy "Always Fallback", always cross-family)
- GROUP-ORCH: GEMINI-ORCH -> OR-REVIEW
- GROUP-CODER-A: OR-CODER-A -> OR-CODER-B -> OR-REVIEW
- GROUP-CODER-B: OR-CODER-B -> OR-CODER-A
- GROUP-REVIEW: OR-REVIEW -> OR-CODER-A
- GROUP-DEPLOY: GEMINI-DEPLOY -> GEMINI-ORCH
- GROUP-FAST: OR-FAST -> OR-OMNI

## Task routing
- Design / data model / tricky logic -> CODER-A. Straight implementation, tests, small fixes, shell work -> CODER-B.
- Any code task -> REVIEW before deploy. UI / Mini App screenshots -> REVIEW (vision).
- Summaries, plan.md logging, log reading, docs -> FAST.
- Anything user-generated or user-facing text (bot replies, listings, comments) -> SAFETY GATE check before publish.
- SAFETY GATE is called with model-use (no tools, plain classification prompt); never put it in a tool-using chat.

## Test before trusting (Model Quick Test + one real task each)
- Lightning and North Mini Code scored low on third-party agentic benchmarks (Artificial Analysis) - keep them on bounded tasks, not long autonomous loops.
- Nemotron 3 Ultra: one third-party price tracker lists it as "deprecated" - confirm on openrouter.ai that the :free slug still works; if not, CODER-A = Super VL.
- Free endpoints are rate limited per account; the fallbacks above are the safety net.
