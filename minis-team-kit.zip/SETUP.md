# Minis Multi-Provider Agent — Setup

## 1. Providers
See skills/team-orchestrator/references/model-roles.md for the full provider/model/role table and fallback groups. One provider entry = one dedicated account/key. To add capacity: new account -> new provider entry -> assign a role.

## 2. Model Groups
Create the groups listed in skills/team-orchestrator/references/model-roles.md (strategy "Always Fallback"). Per group set reasoning level (Coder-A/Reviewer high, Orchestrator/Deployer med, Fast low) and context window. Run "Model Quick Test" on every model (tool calling + Persian). In Vision Input settings choose OR-OMNI as the image describer.

## 3. Environment Variables (Settings → Environment Variables)
Turn ON privacy mode (values are masked before reaching the model).
Secrets (never paste them in chat):
- GITHUB_TOKEN        (fine-grained, only the needed repos: Contents RW, Pull requests RW)
- GITHUB_USER
- CF_API_TOKEN        (scoped: Workers Scripts Edit, KV/D1 Edit if used; NOT global key)
- CF_ACCOUNT_ID
- TG_BOT_TOKEN_<NAME> (one per bot)
- TG_WEBHOOK_SECRET_<NAME>
- OPENROUTER_KEY_CODER_A / _CODER_B / _REVIEW / _FAST / _OMNI / _SAFETY  (needed only if a role is called via model-use from the shell; SAFETY is always called that way)
- GEMINI_KEY_ORCH / GEMINI_KEY_DEPLOY  (same reason)
Non-secret config:
- PROJECT_DIR=/var/minis/shared/projects
- DEFAULT_LANG=fa
You can disable a variable without deleting it (use for temporary lockdown).

## 4. MCP (Settings → MCP Integrations, or `minis-mcp-cli`)
Add GitHub MCP and Cloudflare MCP (OAuth where offered). Rule used by the skills:
- MCP first for reads and structured operations.
- Direct API/CLI (curl, git, wrangler via env vars) when MCP lacks the call.
Use "enable/disable all MCPs in a session" to keep non-deploy roles tool-light.

## 5. Skills
Import ORCHESTRATOR.md, CODER.md, REVIEWER.md, DEPLOYER.md as skills. Keep plan.md template at
$PROJECT_DIR/<project>/plan.md (shared folder is visible in the Files app).
Skill file format may need small adjustment: import one, test, then tell me what Minis changed.

## 6. Runtime features the kit relies on
- Subagents (background, steerable) - test if a subagent can be pinned to a model group.
- model-use passthrough (shell -> any provider) - fallback route to call a specific provider. Check `--help` for exact syntax.
- Ask User cards (never auto-decides), scheduled tasks (retry after rate limit), tool-loop detection,
  context usage indicator, Live Activity / background continued processing, Memory + SOUL.md, Backup (.minisbak),
  App Lock, iCloud sync, minis-config (audited settings changes).
